﻿
DelegatesAndEventsClient.UserTemperatureClasses();
