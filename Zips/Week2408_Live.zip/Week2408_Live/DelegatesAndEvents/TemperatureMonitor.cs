﻿
public class TemperatureMonitorWithEvent
{
	private double _temperature;
	
	public event Action<double>? TemperatureChanged;

	public void Run()
	{
		for (int i = 0; i < 5; i++)
		{
			_temperature = (i * 3.7) + 4;
			TemperatureChanged?.Invoke(_temperature);
		}
	}
}



public interface ITemperatureClient
{
	void TemperatureHasChanged(double t);
}

public class TemperatureMonitorWithInterface
{
	private double _temperature;

	private List<ITemperatureClient> _clients;

	public TemperatureMonitorWithInterface()
	{
		_clients = new List<ITemperatureClient>();
	}

	public void Run()
	{
		for (int i = 0; i < 5; i++)
		{
			_temperature = (i * 3.7) + 4;
			NotifyClients(_temperature);
		}
	}

	public void RegisterClient(ITemperatureClient client)
	{
		_clients.Add(client);
	}

	private void NotifyClients(double t)
	{
		foreach (ITemperatureClient client in _clients)
		{
			client.TemperatureHasChanged(t);
		}
	}
}
