﻿
public class DelegatesAndEventsClient
{
	public static void UseSpeakDelegate()
	{
		// Delegate of type Action
		// Assigning an anonymous method to delegate
		Action speak = () => { Console.WriteLine("Hi There"); };
		speak();
		Console.WriteLine();

		// Adding an anonymous method to delegate
		speak += () => { Console.WriteLine("Hello all"); };
		speak();
		Console.WriteLine();

		// NB, assignment allowed after initialization!
		// Removes all other functions from delegate...
		speak = () => { Console.WriteLine("How are you?"); }; 
		Console.WriteLine();
	}

	public static void UseGreetingsDelegate()
	{
		HelloGreeting hg = new HelloGreeting();
		ByeGreeting bg = new ByeGreeting();

		// Delegate of type Action?
		Action? greetingFuncs = null;

		// Add two functions from objects to delegate
		greetingFuncs += hg.SayHello;
		greetingFuncs += bg.SayBye;

		Console.WriteLine("Executing greetingFuncs by calling greetingFuncs()...");
		greetingFuncs();

		Console.WriteLine("Executing greetingFuncs by calling greetingFuncs?.Invoke()...");
		greetingFuncs?.Invoke(); // Safer because of null check

		// Remove one function from delegate
		greetingFuncs -= hg.SayHello;

		Console.WriteLine("Executing greetingFuncs by calling greetingFuncs?.Invoke()...");
		greetingFuncs?.Invoke();
	}

	public static void UseListOfDelegates()
	{
		// List of delegates of type Func<int, double>
		// Each delegate refers to a single function
		List<Func<int, double>> buffs = new List<Func<int, double>>();
		buffs.Add(BuffEffects.GreaterBlessing);
		buffs.Add(BuffEffects.SatisfyingMeal);
		buffs.Add(BuffEffects.EternalLuck);
		buffs.Add(BuffEffects.LateParty);

		// Single delegate of type Func<int, double>
		// All functions are added to this delegate
		Func<int, double> buffsDelegate = BuffEffects.GreaterBlessing;
		buffsDelegate += BuffEffects.SatisfyingMeal;
		buffsDelegate += BuffEffects.EternalLuck;
		buffsDelegate += BuffEffects.LateParty;


		Console.WriteLine("Buff effect over time with List of delegates");
		for (int time = 0; time < 25; time++)
		{
			double totalEffect = 1.0;
			foreach (Func<int, double> buff in buffs)
			{
				totalEffect = totalEffect * buff(time); // Does work as intended
			}

			Console.WriteLine($"At time {time:00}, total buff effect is {ToPercent(totalEffect):F02} %");
		}

		Console.WriteLine("Buff effect over time with single delegate");
		for (int time = 0; time < 25; time++)
		{
			double totalEffect = 1.0;
			totalEffect = totalEffect * buffsDelegate(time); // Does NOT work as intended

			Console.WriteLine($"At time {time:00}, total buff effect is {ToPercent(totalEffect):F02} %");
		}
	}

	public static void UseListWithEvents()
	{
		ListWithEvents lwe = new ListWithEvents();

		// These three anonymous functions with be called when the List is changed
		lwe.OnListChanged += (ev, val) => { Console.WriteLine($"----------------- {ev} {val}------------------"); };
		lwe.OnListChanged += (ev, val) => { Console.WriteLine($"Hi, List was changed ({ev} for {val})"); };
		lwe.OnListChanged += (ev, val) => { Console.WriteLine($"Hej, List blev ændret ({ev} for {val})"); };

		lwe.Add(12);

		// ListWithEventsClient wants to be notified when the List is changed,
		// specifically by having the method CallMeOnListChanges called.
		ListWithEventsClient lweClient = new ListWithEventsClient();
		lwe.OnListChanged += lweClient.CallMeOnListChanges;

		lwe.Add(24);
		lwe.Remove(343);
		lwe.Remove(12);

		// ListWithEventsClient NO LONGER wants to be notified when the List is changed,
		lwe.OnListChanged -= lweClient.CallMeOnListChanges;

		lwe.Add(33);

		// lwe.OnListChanged = lweClient.CallMeOnListChanges; // NB, assignment NOT allowed.
	}

	public static void UserTemperatureClasses()
	{
		TemperatureMonitorWithEvent tmEvent = new TemperatureMonitorWithEvent();
		UIClientA uicA = new UIClientA();
		UIClientB uicB = new UIClientB();
		UIClientC uicC = new UIClientC();
		UIClientD uicD = new UIClientD();

		tmEvent.TemperatureChanged += uicA.CallMeWhenTemperatureHasChanged;
		tmEvent.TemperatureChanged += uicB.OnTempChange;
		tmEvent.TemperatureChanged += uicC.TemperatureHasChanged;
		tmEvent.TemperatureChanged += uicD.TemperatureHasChanged;
		// tmEvent.TemperatureChanged = uicD.TemperatureHasChanged;  // Nix...
		tmEvent.TemperatureChanged -= uicD.TemperatureHasChanged;
		tmEvent.TemperatureChanged += uicD.TemperatureHasChanged;


		TemperatureMonitorWithInterface tmInterface = new TemperatureMonitorWithInterface();
		// tmInterface.RegisterClient(uicA); // Nix...
		// tmInterface.RegisterClient(uicB); // Nix...
		tmInterface.RegisterClient(uicC);
		tmInterface.RegisterClient(uicD);

		Console.WriteLine("Running TemperatureMonitorWithEvent.Run()...");
		tmEvent.Run();
		Console.WriteLine();

		Console.WriteLine("Running TemperatureMonitorWithInterface.Run()...");
		tmInterface.Run();
		Console.WriteLine();
	}

	private static double ToPercent(double d)
	{
		return (d - 1.0) * 100.0;
	}
}
