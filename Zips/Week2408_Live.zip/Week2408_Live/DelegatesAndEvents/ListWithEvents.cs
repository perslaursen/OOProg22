﻿
public enum ListEvent
{
	Add,
	Remove
}

public class ListWithEvents
{
	private List<int> _numbers;

	/// <summary>
	/// Event that clients (anybody who wants to be notified 
	/// when the List changes) can add a method to, and (perhaps)
	/// later remove the method again.
	/// </summary>
	public event Action<ListEvent, int>? OnListChanged;

	public ListWithEvents()
	{
		_numbers = new List<int>();
	}

	public void Add(int number)
	{
		_numbers.Add(number);

		// Invoke all methods added to the event.
		OnListChanged?.Invoke(ListEvent.Add, number);
	}

	public void Remove(int number)
	{
		if (_numbers.Remove(number))
		{
			// Invoke all methods added to the event.
			OnListChanged?.Invoke(ListEvent.Remove, number);
		}
	}
}

public class ListWithEventsClient
{
	public void CallMeOnListChanges(ListEvent listEvent, int val)
	{
		Console.WriteLine($"ListWithEventsClient:CallMeOnListChanges was called ({listEvent} for {val})");
	}
}
