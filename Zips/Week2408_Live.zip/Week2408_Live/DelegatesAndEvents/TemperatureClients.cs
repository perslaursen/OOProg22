﻿
public class UIClientA
{
	public void CallMeWhenTemperatureHasChanged(double t)
	{
		Console.WriteLine($"From UIClientA ({t:F01})");
	}
}

public class UIClientB
{
	public void OnTempChange(double t)
	{
		Console.WriteLine($"From UIClientB ({t:F01})");
	}
}


public class UIClientC : ITemperatureClient
{
	public void TemperatureHasChanged(double t)
	{
		Console.WriteLine($"From UIClientC ({t:F01})");
	}
}

public class UIClientD : ITemperatureClient
{
	public void TemperatureHasChanged(double t)
	{
		Console.WriteLine($"From UIClientD ({t:F01})");
	}
}
