﻿
public class HelloGreeting
{
	public void SayHello()
	{
		Console.WriteLine("Hello");
	}
}

public class ByeGreeting
{
	public void SayBye()
	{
		Console.WriteLine("Bye");
	}
}
