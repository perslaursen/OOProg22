﻿
public class BuffEffects
{
	public static double GreaterBlessing(int time)
	{
		if (time < 10)
			return 1.16;
		else
			return 1.00;
	}

	public static double SatisfyingMeal(int time)
	{
		if (time < 15)
			return 1.08;
		else
			return 1.00;
	}

	public static double EternalLuck(int time)
	{
		return 1.12;
	}

	public static double LateParty(int time)
	{
		if (time > 20)
			return 1.15;
		else
			return 1.00;
	}
}
