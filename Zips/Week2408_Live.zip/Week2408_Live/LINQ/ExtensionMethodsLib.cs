﻿
/// <summary>
/// NB! Extension methods is not part of the curriculum :-).
/// </summary>
public static class ExtensionMethodsLib
{
	public static int Product(this IEnumerable<int> collection)
	{
		if (collection.Count() == 0)
		{
			throw new ArgumentException();
		}

		int product = 1;

		foreach (int number in collection)
		{
			product = product * number;
		}

		return product;
	}
}
