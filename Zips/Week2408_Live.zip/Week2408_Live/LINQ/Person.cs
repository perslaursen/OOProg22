﻿
public class Person
{
	public string Name { get; }
	public int Born { get; }
	public int ZipCode { get; set; }
	public double Savings { get; set; }

	public Person(string name, int born, int zipCode, double savings = 0)
	{
		Name = name;
		Born = born;
		ZipCode = zipCode;
		Savings = savings;
	}
}
