﻿
public class LINQClient
{
	private static List<City> _cities = new List<City>();
	private static List<Person> _persons = new List<Person>();
	private static List<Movie> _movies = new List<Movie>();


	static LINQClient() // Static Constructor
	{
		_cities = new List<City>();
		_cities.Add(new City("Roskilde", 4000, 50000));
		_cities.Add(new City("Ballerup", 2750, 40000));
		_cities.Add(new City("Lejre",    4320,  3100));
		_cities.Add(new City("Jyllinge", 4040, 10700));


		_persons = new List<Person>();
		_persons.Add(new Person("Anne",   1982, 4000, 500000));
		_persons.Add(new Person("Brian",  1976, 4040,  25000));
		_persons.Add(new Person("Carina", 1969, 2750, 120000));
		_persons.Add(new Person("Dan",    1967, 4000,  40000));
		_persons.Add(new Person("Erik",   1970, 2750, 200000));
		_persons.Add(new Person("Frida",  1991, 4000, 800000));


		_movies = new List<Movie>();
		_movies.Add(new Movie("Se7en", 1995, 127, "New Line Cinema"));
	}


	public static void UseSelect_OperatorSyntax()
	{
		IEnumerable<string> names = from p in _persons
									select p.Name;
		PrintCollection(names, "Names");


		IEnumerable<double> savings = from p in _persons
									  select p.Savings;
		PrintCollection(savings, "Savings");


		var multiPropA = from p in _persons
						 select new { p.Name, p.Savings }; // Anonymous type
		PrintCollection(multiPropA, "Multi-property");


		var multiPropB = from p in _persons
						 select new { p.Name, TotalSavings = p.Savings }; // Anonymous type with named property
		PrintCollection(multiPropB, "Multi-property (named property)");


		var totalSavingsA = from m in multiPropB
						    select m.TotalSavings;
		PrintCollection(totalSavingsA, "Total savings A");


		var totalSavingsB = from m in multiPropB
							select $"Total saving for {m.Name} is {m.TotalSavings}" ;
		PrintCollection(totalSavingsB, "Total savings B");


		var totalSavingsC = from m in (from p in _persons select new { p.Name, TotalSavings = p.Savings })
						    select m.TotalSavings;
		PrintCollection(totalSavingsC, "Total savings C");
	}

	public static void UseSelect_FluentSyntax()
	{
		IEnumerable<string> names = _persons.Select(p => p.Name);
		PrintCollection(names, "Names");


		IEnumerable<double> savings = _persons.Select(p => p.Savings);
		PrintCollection(savings, "Savings");


		var multiPropA = _persons.Select(p => new { p.Name, p.Savings }); // Anonymous type
		PrintCollection(multiPropA, "Multi-property");


		var multiPropB = _persons.Select(p => new { p.Name, TotalSavings = p.Savings }); // Anonymous type with named property
		PrintCollection(multiPropB, "Multi-property (named property)");


		var totalSavingsA = multiPropB.Select(m => m.TotalSavings);
		PrintCollection(totalSavingsA, "Total savings A");


		var totalSavingsB = multiPropB.Select(m => $"Total saving for {m.Name} is {m.TotalSavings}");
		PrintCollection(totalSavingsB, "Total savings B");


		var totalSavingsC = _persons.Select(p => new { p.Name, TotalSavings = p.Savings }).Select(m => m.TotalSavings);
		PrintCollection(totalSavingsC, "Total savings C");
	}

	public static void UseWhere_OperatorSyntax()
	{
		// Names for all Persons born before 1980
		IEnumerable<string> namesA = from p in _persons
									 where p.Born < 1980
									 select p.Name;
		PrintCollection(namesA, "Names for all Persons born before 1980");


		// Savings for all Persons born before 1980
		IEnumerable<double> savings = from p in _persons
									  where p.Born < 1980
									  select p.Savings;
		PrintCollection(savings, "Savings for all Persons born before 1980");


		// Names for all Persons born before 1980 with more than 100000 in savings
		IEnumerable<string> namesB = from p in _persons
									 where p.Born < 1980 && p.Savings > 100000
									 select p.Name;
		PrintCollection(namesB, "Names for all Persons born before 1980 with more than 150000 in savings");
	}

	public static void UseWhere_FluentSyntax()
	{
		// Names for all Persons born before 1980
		IEnumerable<string> namesA = _persons
			.Where(p => p.Born < 1980)
			.Select(p => p.Name);
		PrintCollection(namesA, "Names for all Persons born before 1980");


		// Savings for all Persons born before 1980
		IEnumerable<double> savings = _persons
			.Where(p => p.Born < 1980)
			.Select(p => p.Savings);
		PrintCollection(savings, "Savings for all Persons born before 1980");


		// Names for all Persons born before 1980 with more than 100000 in savings
		IEnumerable<string> namesB = _persons
			.Where(p => p.Born < 1980 && p.Savings > 100000)
			.Select(p => p.Name);
		PrintCollection(namesB, "Names for all Persons born before 1980 with more than 150000 in savings");
	}

	public static void UseOnNumbers()
	{
		List<int> numbers = new List<int> { 17, 32, 98, 10, 42, 77, 23 };


		var squares = numbers.Select(n => new { Number = n, Square = n * n });
		PrintCollection(squares, "Squares");


		IEnumerable<int> highNumbers = numbers.Where(n => n > 50);
		PrintCollection(highNumbers, "High Numbers");


		List<int> highNumbersToList = numbers
			.Where(n => n > 50)
			.ToList();
		PrintCollection(highNumbersToList, "High Numbers as List");


		var squaresToDictionary = numbers
			.Select(n => new { Number = n, Square = n * n })
			.ToDictionary(ns => ns.Number, ns => ns.Square); ;
		PrintCollection(squaresToDictionary, "Squares as Dictionary");
	}

	public static void UseOwnExtensionMethod()
	{
		HashSet<int> numbersA = new HashSet<int> { 2, 5, 12, 3 };
		List<int> numbersB = new List<int> { 3, 1, 17, 19 };

		Console.WriteLine($"Product is {numbersA.Product()}");
		Console.WriteLine($"Product is {numbersB.Product()}");
	}

	public static void UseMovies_OperatorSyntax()
	{
		// var query0 = from m in _movies; // NB: Not valid

		// SQL:
		// SELECT Title FROM Movie
		var queryA = from m in _movies
					 select m.Title;

		// SQL:
		// SELECT Title, Year FROM Movie
		var queryB = from m in _movies
					 select new { m.Title, m.Year };  // Anonymous type

		PrintCollection(queryA, "Movies queryA");
		PrintCollection(queryB, "Movies queryB");


		// SQL:
		// SELECT Title, Year FROM Movie
		// WHERE Year < 1996
		var queryC = from m in _movies
					 where m.Year < 1996
					 select new { m.Title, m.Year };
	}

	public static void UseMovies_FluentSyntax()
	{
		// var query0 = from m in _movies; // NB: Not valid

		// SQL:
		// SELECT Title FROM Movie
		var queryA = _movies.Select(m => m.Title);

		// SQL:
		// SELECT Title, Year FROM Movie
		var queryB = _movies.Select(m => new { m.Title, m.Year });  // Anonymous type

		PrintCollection(queryA, "Movies queryA");
		PrintCollection(queryB, "Movies queryB");


		// SQL:
		// SELECT Title, Year FROM Movie
		// WHERE Year < 1996
		var queryC = _movies
			.Where(m =>  m.Year < 1996)
			.Select(m => new { m.Title, m.Year });
	}

	private static void PrintCollection<T>(IEnumerable<T> collection, string text = "")
	{
		Console.WriteLine(string.IsNullOrEmpty(text) ? "" : $"---- {text} ----");

		foreach (T t in collection)
		{
			Console.WriteLine(t);
		}
		Console.WriteLine();
	}
}
