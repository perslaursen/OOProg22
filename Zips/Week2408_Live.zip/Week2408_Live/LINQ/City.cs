﻿
public class City
{
	public string Name { get; }
	public int ZipCode { get; }
	public int Population { get; set; }

	public City(string name, int zipCode, int population)
	{
		Name = name;
		ZipCode = zipCode;
		Population = population;
	}
}
