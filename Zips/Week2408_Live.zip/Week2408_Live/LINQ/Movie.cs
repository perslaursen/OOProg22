﻿
public class Movie
{
	public string Title { get; }
	public int Year { get; }
	public int DurationInMins { get; }
	public string StudioName { get; }

	public Movie(string title, int year, int duration, string studioName)
	{
		Title = title;
		Year = year;
		DurationInMins = duration;
		StudioName = studioName;
	}
}

